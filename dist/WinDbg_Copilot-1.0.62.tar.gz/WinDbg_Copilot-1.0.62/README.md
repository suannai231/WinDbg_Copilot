# WinDbg Copilot

WinDbg Copilot is a ChatGPT-powered AI assistant integrated with WinDbg. It analyzes the output of the commands and provides guidance to solve the stated problem.

## Prerequisites

1. **Operating System:** Windows 10 and above.
2. **OpenAI API:** If you want to use OpenAI API, add environment variable:
   ```
   OPENAI_API_KEY = <Openai API Key>
   ```
3. **Azure OpenAI:** If you want to use Azure OpenAI, add the following environment variables:
   ```
   AZURE_OPENAI_ENDPOINT = <Azure OpenAI Endpoint>
   AZURE_OPENAI_KEY = <Azure OpenAI Key>
   AZURE_OPENAI_DEPLOYMENT = <Azure OpenAI Deployment Name>
   ```
4. **Debugging Tools for Windows WinDbg (classic):** Installed on your machine.
   ```
   Download URL: https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/debugger-download-tools
   Add environment variable WinDbg_PATH = C:\Program Files\Debugging Tools for Windows (x64).
   Add environment variable _NT_SYMBOL_PATH = srv*c:\symbols*https://msdl.microsoft.com/download/symbols
   ```
5. **Python:** Version >=3.9, <3.12 installed on your machine.
6. **Internet Connection:** For downloading and installing the package.

## Installation

1. Ensure you have Python installed.
2. Open the Command Prompt or PowerShell.
3. Install the package using pip:
   ```
   pip install WinDbg_Copilot
   ```

## Running the Console and GUI versions

Users can run the console or GUI version as follows:

### Running the Console App:

Simply type in the Command Prompt or PowerShell:
```
windbg-copilot-console
```

### Running the GUI App:

Type in the Command Prompt or PowerShell:
```
windbg-copilot-gui
```

## Running using Python:

If users want to run the apps directly using Python:

### Running the Console App:

```
python -m WinDbg_Copilot.WinDbg_Copilot_Console
```

### Running the GUI App:

```
python -m WinDbg_Copilot.WinDbg_Copilot_GUI
```
# WinDbg Copilot Console App

Hello, I am WinDbg Copilot, I'm here to assist you.

The given commands are used to interact with WinDbg Copilot, a tool that utilizes the OpenAI model for assistance with debugging. The commands include:

        !auto: auto mode, user provides a problem description, ChatGPT can reply with simple explanations or suggesting a single command to execute to further analyze the problem. Ask user to execute the suggested command or not.
        !chat: chat mode, user inputs are forwarded to ChatGPT, ChatGPT can reply with simple answers or suggesting a single command to execute to further analyze the problem.
        !command: command mode, user inputs are forwarded to debugger like manual debugging in WinDbg, debugger outputs are forwarded to ChatGPT, ChatGPT can reply with simple explanations or suggesting a single command to execute to further analyze the problem. User will decide to execute the suggested command or not.
        !quit or !q or q or qq: Terminates the debugger session.
        !help or !h: Provides help information.

Note: WinDbg Copilot requires an active Internet connection to function properly, as it relies on Openai API.

# WinDbg Copilot GUI App

Welcome to the WinDbg Copilot GUI App - your go-to solution for an enhanced debugging experience powered by AI!

## New Feature: Tab Widget

We have introduced a tab widget to the GUI application:

1. **Auto Tab:** Users provide a problem description, AI assistant guides the debugging process until no more suggestions or solution has been found.
2. **Chat Tab:** A unique interactive experience for more advanced users with existing WinDbg and debugging skills. Users can talk freely with the AI assistant, ask any debugging questions, and the AI assistant will reply with simple answers and provide an executable command. Users can execute the suggested command in the command window, and the AI assistant will process the WinDbg output and reply with further instructions.

## Overview

The WinDbg Copilot GUI App seamlessly blends the power of WinDbg with the intelligence of OpenAI, providing you with intelligent suggestions throughout your debugging session. With configurable settings, support for various file types, an integrated AI assistant, and the newly added tab widget, this app takes debugging to a whole new level.

## Features

1. **Configurable Settings Menu:** Tailor the app to your needs through a user-friendly settings menu.
2. **File Support:** Open local memory dump files or time travel trace files directly within the app.
3. **Remote Debugger Connection:** Need to debug remotely? Connect effortlessly to a remote debugger from within the app.
4. **Integrated WinDbg Command Window:** Positioned on the left side of the app; View debugger outputs conveniently in a dedicated text widget; Enter your debug commands in an entry widget located just below the display.
5. **AI-Powered Assistant with Tab Widget:** Now enjoy the flexibility of Auto and Chat tabs for different debugging experiences.

## How It Works

1. Begin by entering a problem description in the AI assistant window.
2. Send this description to OpenAI via the app.
3. Receive a suggested debug command from OpenAI, presented as a clickable link.
4. Click on the suggestion to execute it in the WinDbg command window.
5. View the debugger output and await further suggestions from the AI assistant.
6. Continue this interactive process until you receive no more suggestions or until your problem is resolved.

# Uninstallation

Open a command prompt or terminal window. Use pip to uninstall the WinDbg Copilot package:

```
pip uninstall WinDbg_Copilot
```

The packages will be uninstalled automatically.

## Conclusion

Gone are the days of sifting through endless logs and documentation. With the WinDbg Copilot GUI App, you have a powerful AI sidekick to guide you through the debugging process, making it more intuitive, interactive, and efficient. Happy debugging!

# Disclaimer: WinDbg Copilot

WinDbg Copilot is an application designed for debugging learning purposes only. It is important to note that this application should not be used to load or handle any customer data. WinDbg Copilot is intended solely for the purpose of providing a platform for debugging practice and learning experiences.

When using WinDbg Copilot, please be aware that any debugging input and output generated during your debugging sessions will be sent to OpenAI or Azure OpenAI according to your selection. This data may be used for analysis and improvement of the application's performance and capabilities. However, it is crucial to understand that no customer data should be loaded or shared through WinDbg Copilot.

WinDbg Copilot project takes the privacy and security of user information seriously and endeavors to handle all data with utmost care and in accordance with applicable laws and regulations. Nevertheless, it is strongly recommended to refrain from providing any sensitive or confidential information while using WinDbg Copilot.

By using WinDbg Copilot, you acknowledge and agree that any debugging input and output you generate may be transmitted to OpenAI or Azure OpenAI for research and development purposes. You also understand that WinDbg Copilot should not be used with customer data and that WinDbg Copilot project is not responsible for any consequences that may arise from the misuse or mishandling of such data.

Please ensure that you exercise caution and adhere to best practices when utilizing WinDbg Copilot to ensure the privacy and security of your own data. WinDbg Copilot project will not be held liable for any damages, losses, or unauthorized access resulting from the misuse of this application.

By proceeding to use WinDbg Copilot, you signify your understanding and acceptance of these terms and conditions.